extends CanvasLayer

signal start_game

@export var heart_texture: Texture  # arrastra tu heart.png aquí en el editor
var heart_nodes = []

func show_message(text):
	$MessageLabel.text = text
	$MessageLabel.show()
	$MessageTimer.start()


func show_game_over():
	show_message("Game Over")
	await $MessageTimer.timeout
	$MessageLabel.show()
	await get_tree().create_timer(1).timeout
	$StartButton.show()


func update_score(score):
	$ScoreLabel.text = str(score)

func update_lives(lives):
	# Limpiar corazones viejos
	for heart in heart_nodes:
		heart.queue_free()
	heart_nodes.clear()
	
	# Crear un corazón por cada vida
	for i in range(lives):
		var heart = TextureRect.new()
		heart.texture = heart_texture
		heart.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT
		$HeartsContainer.add_child(heart)
		heart_nodes.append(heart)
	
	# Actualizar el texto existente
	if has_node("LivesLabel"):
		$LivesLabel.text = "Vidas: " + str(lives)


func _on_StartButton_pressed():
	$StartButton.hide()
	start_game.emit()


func _on_MessageTimer_timeout():
	$MessageLabel.hide()
