extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	connect("body_entered", Callable(self, "_on_body_entered"))
	pass # Replace with function body.

func _on_body_entered(body):
	if body.is_in_group("player"): # Asegúrate que tu jugador esté en el grupo "player"
		body.make_smaller()
		queue_free()
		
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
